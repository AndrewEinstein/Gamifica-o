from .operacoes import soma, subtracao, divisao, multiplicacao
from .avancados import quadrado, cubo