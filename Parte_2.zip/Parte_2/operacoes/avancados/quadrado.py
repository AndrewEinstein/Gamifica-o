def quadrado(num):
    return num ** 2