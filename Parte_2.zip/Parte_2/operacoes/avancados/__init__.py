from .quadrado import quadrado
from .cubo import cubo