def cubo(num):
    return num ** 3